from django.apps import AppConfig


class TsConfig(AppConfig):
    name = 'ts'
